<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title >Assignment 2</title>
        <?php
         echo '<h1 align="center" style="font-family:verdana">Assignment 2</h1>';
         ?>
    </head>
    <body style="background-color:rgb(191, 201, 202);">
        
        <?php
        ?>
    </body>
</html>

