<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title >Austin Duran</title>
        <div class="topnav">
        <a class="active" href="index.php">Home</a>
        <a href="Assignment_1.php">Assignment 1</a>
        <a href="Assignment_2.php">Assignment 2</a>
        <a href="Assignment_3.php">Assignment 3</a>
        <a href="E-Commerce.php">E-Commerce</a>
        <a href="Class Room Exercises.php">Class Room Exercises</a>
        </div> 
    
        <style type="text/css">
        .myImage
        {
            margin: auto;
            display: block; 
        }    
                /* Add a black background color to the top navigation */
        .topnav {
          background-color: #333;
          overflow: hidden;
        }

        /* Style the links inside the navigation bar */
        .topnav a {
          float: left;
          color: #f2f2f2;
          text-align: center;
          padding: 14px 16px;
          text-decoration: none;
          font-size: 17px;
        }

        /* Change the color of links on hover */
        .topnav a:hover {
          background-color: #ddd;
          color: black;
        }

        /* Add a color to the active/current link */
        .topnav a.active {
          background-color: #4CAF50;
          color: white;
}   
        </style>
        
        
        
        <?php
        //Displaying Header Text 'Austin Duran'
         echo '<h1 align="center" style="font-family:verdana">Austin Duran</h1>';
         ?>
    </head>
    <body style="background-color:rgb(191, 201, 202);">
        
        <?php
        //Displaying Image
        echo '<img src="../images/austin_duran_resize.jpg" alt="My Image" class="myImage"/>';
        
        //Displaying Introduction
        echo '<p align="center|justify" style="font-family:verdana"><b>Hi there! You\'ve reached my website. '
        . 'A short intro about me:</b><br /> &nbsp;&nbsp;&nbsp;&nbsp;I currently attend SLCC taking courses for the Weber State Computer'
                . ' Science program <br /> &nbsp;&nbsp;&nbsp;&nbsp;I work as a Software Engineer in Test at Sorenson Communications'
                . ' <br /> &nbsp;&nbsp;&nbsp;&nbsp;I love to code <br /> &nbsp;&nbsp;&nbsp;&nbsp;My wife and I are expecting a baby boy in May '
                . '<br /> &nbsp;&nbsp;&nbsp;&nbsp;My favorite book is Richard Lyman Bushman\'s Joseph Smith, Rough Stone Rolling <br /> '
                . '&nbsp;&nbsp;&nbsp;&nbsp;My favorite film is Interstellar </p>'
        ?>
    </body>
</html>

