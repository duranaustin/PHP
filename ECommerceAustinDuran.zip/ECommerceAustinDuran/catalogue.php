<?php
include 'header.php';
session_start();

$product_id = $_POST['Select_Product'];
$action = $_POST['action'];
switch ($action){
    case "Add":
        $_SESSION['cart'][$product_id] ++;
        break;
    case "Remove":
        $_SESSION['cart'][$product_id] --;
        if($_SESSION['cart'][$product_id] <= 0)
            unset($_SESSION['cart'][$product_id]);
        break;
    case "Empty":
        unset($_SESSION['cart']);
        break;
    case "Info":
        $infonum = $product_id;
        break;
        
}

print_r($_SESSION);
require_once 'DataBaseConnection.php';
?>
<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>E-Commerce catalogue</title>
        <link href="/CSIS2440/CodeEx/view.css" rel="stylesheet" type="text/css">
    </head>
    <body>
        <div class="form" id="form_container">
            <form action="catalogue.php" method="Post">
                <div >

                    <p><span class="text">Please Select a product:</span>
                        <select id="Select_Product" name="Select_Product" class="select">
                            <option value=""></option>
                            <?php
                            
                            $search = "SELECT Name, ProductID FROM Library.Products order by Name";
                            $return = $con->query($search);
                            
                            if(!$return){
                                $message = "Whole query: " . $search;
                                echo $message;
                                die('Invalid query: ' . mysqli_error());
                            }
                            while ($row = mysqli_fetch_array($return)){
                                if ($row['ProductID'] == $product_id){
                                    echo "<option value='" . $row['ProductID']."' selected='selected'". $row['Name'] . "<option>\n";
                                } else{
                                    echo "<option value='" . $row['ProductID'] . "'>". $row['Name'] . "</option>\n";
                                }
                            }
                            ?>
                        </select></p>
                    <table>
                        <tr>
                            <td>
                                <input id="button_Add" type="submit" value="Add" name="action" class="button"/>
                            </td>
                            <td>
                                <input name="action" type="submit" class="button" id="button_Remove" value="Remove"/>
                            </td>
                            <td>
                                <input name="action" type="submit" class="button" id="button_empty" value="Empty"/>
                            </td>
                            <td>
                                <input name="action" type="submit" class="button" id="button_Info" value="Info"/>
                            </td>
                        </tr>                    
                    </table>

                </div>
                <div id="productInformation">

                </div>
                <div>
                                    </div>
                <div id="Display_cart">
                    <?php
                    if ($_SESSION['cart']) {
                        echo "<table border=\"1\" padding=\"3\" width=\"640px\"><tr><th>Name</th><th>Weight</th><th>Price</th>"
                        ."<th width=\"80px\">Line</th></tr>";
                        foreach ($_SESSION['cart'] as $product_id => $quantity){
                            $sql = "SELECT Name, Price, Weight FROM Library.Products WHERE ProductID = " . $product_id;
                            echo $sql;
                            $result = $con->query($sql);
                            
                            if(mysqli_num_rows($result) > 0){
                                list($name, $price, $weight) = mysqli_fetch_row($result);
                                $weight = $weight * $quantity;
                                $line_cost = $price * $quantity;
                                $line = number_format($line_cost, 2);
                                $totweight = $totWeight + $weight;
                                $total = $total + $line_cost;
                                echo"<tr>";
                                echo"<td align=\"Left\" width=\"450px\">$name</td>";
                                echo"<td align=\"center\" width=\"75px\">$weight</td>";
                                echo"<td align=\"center\" width=\"75px\">$price</td>";
                                echo"<td align=\"center\" width=\"75px\">$line</td>";
                                echo"</tr>";
                            }
                        }
                        echo"<tr>";
                        echo"<td align=";
                        
                        
                        
                    }
//                        echo table
                        foreach ($_SESSION['cart'] as $product_id => $quantity)
                        {
                        echo"You have no items in your shopping cart.";
                    }
                    mysqli_close($con)
                    ?>
                </div>
            </form>
        </div>
    </body>
</html>
