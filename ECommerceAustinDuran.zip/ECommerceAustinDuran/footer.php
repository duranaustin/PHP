

</div><!--Closing the container-->
</div><!--Closing the row-->
<div class="row">
  <div class="col-sm-4"></div>
  <div class="col-sm-4" style="align-content: center">Created for CSIS2440@SLCC</div>
  <div class="col-sm-4"></div>
</div>

<script src=
        "https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js">
</script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>