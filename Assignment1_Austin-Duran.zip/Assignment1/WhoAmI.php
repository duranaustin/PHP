<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Assignment 1 - Austin Duran</title>
        <link href="/CSIS2440/CodeEx/view.css" rel="stylesheet" type="text/css">
    </head>
        <body>
        <form action="WhoYouAre.php" method="post">
        <?php
            print <<<HTML
            Please tell us who you are.<br> 
            Name: <input type="text" name="Name"><br>
            Age: <input type="number" name="Age"><br>
            Address: <input type="text" name="Address"><br>
            State: <input type="text" name="State"><br>
            Gender: Female<input type="radio" value="Female" name="Gender" checked="true"> Male<input type="radio" value="Male" name="Gender" checked="true">
            <br>
            <input type="submit" value="Submit" name="Submit"><br>
HTML;
           ?>
        </form>
    </body>
</html>



