<?php
$name = htmlentities($_POST['Name']);
$name = strtolower($name);
$name = strtoupper($name);
$name = ucwords($name);
$age = $_POST['Age'];
$address = $_POST['Address'];
$state = $_POST['State'];
$gender = $_POST['Gender'];
?>
<head>
    <meta charset="utf-8">
    <title> Who You Are </title>
    <link href="view.css" rel="stylesheet" type="text/css"/>
    <style>
        img {
            height: 250px;
            padding: 3pt;
            float: right;
        }
    </style>
</head>

<body>
    <div id="form_container">
        <h3 class="Content">Who You Are</h3>
        <div class="CharacterSheet">
            <?php
            // Print-r of all $_POST variables returned from form
            print_r($_POST);
            
            // If Gender is equal to Male - change the background - else leave default
            if ($gender == "Male"){
            echo("<body style='background-color:rgb(191, 201, 202);'>");
            }
            
            // Print the Current date and all preceding years from given $date
            echo ("<br><br>");
            for ($i = 0; $i-2 != $age; $i++){// $i = $i-2 because we retroactively handle the date('Y')
                echo(date("Y") - $i);
                echo(" -&nbsp");
            }
            
            // Require PostPage.txt
            echo("<br><br>");
            require "PostPage.txt";
            ?>         
        </div>
    </div> 
</body>
</html>



